import threading
print(f"我是主线程{threading.current_thread().name}")
